require "test_helper"

class PurchaseProductTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
